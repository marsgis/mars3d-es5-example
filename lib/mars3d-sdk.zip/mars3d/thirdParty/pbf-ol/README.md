# Cesium对mvt的pbf的矢量瓦片图层的扩展插件
 

 基于openlayer框架对pbf的解析，引接到cesium中来。 


 其中olms为从Mapbox样式规范的OpenLayers插件：https://github.com/openlayers/ol-mapbox-style
