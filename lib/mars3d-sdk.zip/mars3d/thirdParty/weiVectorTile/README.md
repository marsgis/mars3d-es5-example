## 支持小数据量的geojson、shape文件矢量动态切片，实现贴地
 
 github：https://github.com/muyao1987/CesiumVectorTile
 
 
### 依赖
- [Cesium](https://github.com/CesiumGS/cesium)
- [turf](https://github.com/Turfjs/turf) 
