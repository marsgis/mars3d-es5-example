#Cesium 功能扩展插件

说明： 添加heatmap热力图到Cesium框架。


github地址：https://github.com/manuelnas/CesiumHeatmap

 